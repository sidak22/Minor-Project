# Prediction of high yield crops in Punjab using Machine Learning.

### Install required libraries
``` pip install \Text Files\requirements.txt```

### Algorithms used
> Linear Regression,
> KNN,
> Random Forest,
> Gradient Boosting

### Get predicted outcomes
Input year, district, season, rainfall, etc data in model2.py
